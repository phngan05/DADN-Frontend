import { useState } from 'react';
import apiClient from '@/src/services/api';

export function useDeviceControl() {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const updateStatus = async (feed_key: string, value: number) => {
        setLoading(true);
        setError(null);
        try {
            await apiClient.put(`record`, {
                feed_key: feed_key,
                value: value,
            });
            return true;
        } catch (err: any) {
            setError(err.message || "Something went wrong");
            return false;
        } finally {
            setLoading(false);
        }
    };
    const verifyPassword = async (inputPassword: string) => {
        try {
            const response = await apiClient.post("/door", { 
                password: inputPassword 
            });
            
            return response.data;
        } catch (err: any) {
            setError(err.message || "Incorrect Password!");
            return false;
        }
    }

    const updatePassword = async (oldPassword: string, newPassword: string) => {
        try {
            const response = await apiClient.put("/door", { 
                old_password: oldPassword,
                new_password: newPassword,
            });
            return response.data            
        } catch (err: any) {
            setError(err.message || "Update password failed!");
        }
    }
    return { updateStatus, verifyPassword, updatePassword, loading, error };
}